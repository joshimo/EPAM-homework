package assigment06.task01;

public interface IEngine {

    public boolean start();

    public boolean work();

    public boolean stop();

}
